from django.contrib import admin
from .models import Estudiante
# Register your models here.
class AdminEstudiante(admin.ModelAdmin):
    list_display = ["matricula", "cedula", "nombres", "apellidos", "ciclo", "carrera"]
    list_editable = ["cedula", "nombres"]
    list_filter = ["matricula"]
    class Meta:
        model = Estudiante
admin.site.register(Estudiante, AdminEstudiante)

